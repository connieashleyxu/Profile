//
//  ViewController.swift
//  XuConnieHW1
//
//  Created by Connie Xu on 8/26/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

